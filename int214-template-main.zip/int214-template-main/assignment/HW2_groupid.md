# Assignment 2 (Group)
Explore 2 dataset that given then finding descriptive statistics and summary result in form of sentences/paragraph at least 5 topics.

### Answer

1.) From survey, most students use left hand writing.
```{R}
Code here
```

2.) Descriptive statistics Statement
```{R}
Code here
```


### Team: xxxxxxx

1. ชื่อ นามสกุล     StudentID: 63130500xxx
2. ชื่อ นามสกุล     StudentID: 63130500xxx
3. ชื่อ นามสกุล     StudentID: 63130500xxx
4. ชื่อ นามสกุล     StudentID: 63130500xxx
5. ชื่อ นามสกุล     StudentID: 63130500xxx