# GroupID-Datasetname
Datasets from: xxxxxxx

## Objective

## Process

## Result

## About Us
งานนี้เป็นส่วนของวิชา INT214 Statistics for Information technology <br/> ภาคเรียนที่ 1 ปีการศึกษา 2564 คณะเทคโนโลยีสารสนเทศ มหาวิทยาลัยเทคโนโลยีพระจอมเกล้าธนบุรี
### Team: xxxxxxx
1. ชื่อ นามสกุล     StudentID: 63130500xxx
2. ชื่อ นามสกุล     StudentID: 63130500xxx
3. ชื่อ นามสกุล     StudentID: 63130500xxx
4. ชื่อ นามสกุล     StudentID: 63130500xxx
5. ชื่อ นามสกุล     StudentID: 63130500xxx

### Instructor
- ATCHARA TRAN-U-RAIKUL
- JATAWAT XIE (Git: [safesit23](https://github.com/safesit23))



